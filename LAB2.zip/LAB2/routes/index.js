'use strict';
var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function (req, res) {
    function calculator(method, x, y) {
        if (method = "add") {
            console.log(x + y);
        }
        else if (method = "subtract") {
            console.log(x - y);
        }
        else if (method = "multiply") {
            console.log(x * y);
        }
        else if (method = "divide") {
            console.log(x / y);
        }
        else {
            console.log("try valid values");
        }


    }
    console.log(req.query);
    console.log(req.query.method);

    res.render('index', { title: 'Express' });
});

module.exports = router;
